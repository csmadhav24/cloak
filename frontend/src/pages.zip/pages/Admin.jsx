import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';

function Admin() {
  const [users, setUsers] = useState([]);
  const [stats, setStats] = useState(null);
  const [auditLogs, setAuditLogs] = useState([]);
  const [activeTab, setActiveTab] = useState('users');

  useEffect(() => {
    fetchUsers();
    fetchStats();
    fetchAuditLogs();
  }, []);

  const fetchUsers = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8000/api/admin/users', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8000/api/admin/stats', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const fetchAuditLogs = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8000/api/audit/logs?page=1&page_size=20', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setAuditLogs(data.logs || []);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
    }
  };

  const updateUserRole = async (userId, newRole) => {
    try {
      const token = localStorage.getItem('token');
      await fetch(`http://localhost:8000/api/admin/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ role: newRole })
      });
      fetchUsers();
    } catch (error) {
      alert('Failed to update user role');
    }
  };

  const lockUser = async (userId, lock) => {
    try {
      const token = localStorage.getItem('token');
      await fetch(`http://localhost:8000/api/admin/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ account_locked: lock })
      });
      fetchUsers();
    } catch (error) {
      alert('Failed to update user status');
    }
  };

  const formatBytes = (bytes) => {
    if (!bytes) return '0 B';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <Layout title="Admin Panel">
      {/* Tabs */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
        <button
          onClick={() => setActiveTab('users')}
          style={{
            padding: '10px 20px',
            background: activeTab === 'users' ? '#667eea' : 'white',
            color: activeTab === 'users' ? 'white' : '#333',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer'
          }}
        >
          Users
        </button>
        <button
          onClick={() => setActiveTab('stats')}
          style={{
            padding: '10px 20px',
            background: activeTab === 'stats' ? '#667eea' : 'white',
            color: activeTab === 'stats' ? 'white' : '#333',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer'
          }}
        >
          Statistics
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          style={{
            padding: '10px 20px',
            background: activeTab === 'audit' ? '#667eea' : 'white',
            color: activeTab === 'audit' ? 'white' : '#333',
            border: 'none',
            borderRadius: '5px',
            cursor: 'pointer'
          }}
        >
          Audit Logs
        </button>
      </div>

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div style={{ background: 'white', borderRadius: '10px', padding: '20px', overflowX: 'auto' }}>
          <h3>User Management</h3>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #eee' }}>
                <th style={{ padding: '12px', textAlign: 'left' }}>Username</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>Email</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>Role</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>Status</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} style={{ borderBottom: '1px solid #eee' }}>
                  <td style={{ padding: '12px' }}>{user.username}</td>
                  <td style={{ padding: '12px' }}>{user.email}</td>
                  <td style={{ padding: '12px' }}>
                    <select
                      value={user.role}
                      onChange={(e) => updateUserRole(user.id, e.target.value)}
                      style={{ padding: '5px', borderRadius: '5px' }}
                    >
                      <option value="user">User</option>
                      <option value="admin">Admin</option>
                      <option value="auditor">Auditor</option>
                    </select>
                  </td>
                  <td style={{ padding: '12px' }}>
                    <span style={{
                      color: user.account_locked ? 'red' : 'green',
                      background: user.account_locked ? '#fee' : '#efe',
                      padding: '4px 8px',
                      borderRadius: '20px',
                      fontSize: '12px'
                    }}>
                      {user.account_locked ? 'Locked' : 'Active'}
                    </span>
                  </td>
                  <td style={{ padding: '12px' }}>
                    <button
                      onClick={() => lockUser(user.id, !user.account_locked)}
                      style={{
                        background: user.account_locked ? '#10b981' : '#ef4444',
                        color: 'white',
                        border: 'none',
                        padding: '6px 12px',
                        borderRadius: '5px',
                        cursor: 'pointer'
                      }}
                    >
                      {user.account_locked ? 'Unlock' : 'Lock'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Statistics Tab */}
      {activeTab === 'stats' && stats && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '20px' }}>
          <div style={{ background: 'white', borderRadius: '10px', padding: '20px', textAlign: 'center' }}>
            <div style={{ fontSize: '48px' }}>👥</div>
            <h3>Total Users</h3>
            <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '10px 0' }}>{stats.total_users || 0}</p>
          </div>
          <div style={{ background: 'white', borderRadius: '10px', padding: '20px', textAlign: 'center' }}>
            <div style={{ fontSize: '48px' }}>📄</div>
            <h3>Total Files</h3>
            <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '10px 0' }}>{stats.total_files || 0}</p>
          </div>
          <div style={{ background: 'white', borderRadius: '10px', padding: '20px', textAlign: 'center' }}>
            <div style={{ fontSize: '48px' }}>💾</div>
            <h3>Storage Used</h3>
            <p style={{ fontSize: '24px', fontWeight: 'bold', margin: '10px 0' }}>{formatBytes(stats.total_storage_bytes)}</p>
          </div>
          <div style={{ background: 'white', borderRadius: '10px', padding: '20px', textAlign: 'center' }}>
            <div style={{ fontSize: '48px' }}>🔄</div>
            <h3>Active Sessions</h3>
            <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '10px 0' }}>{stats.active_sessions || 0}</p>
          </div>
        </div>
      )}

      {/* Audit Logs Tab */}
      {activeTab === 'audit' && (
        <div style={{ background: 'white', borderRadius: '10px', padding: '20px', overflowX: 'auto' }}>
          <h3>System Audit Logs</h3>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
            <thead>
              <tr style={{ borderBottom: '2px solid #eee' }}>
                <th style={{ padding: '12px', textAlign: 'left' }}>Time</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>User</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>Event</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>Severity</th>
                <th style={{ padding: '12px', textAlign: 'left' }}>IP Address</th>
              </tr>
            </thead>
            <tbody>
              {auditLogs.map((log) => (
                <tr key={log.id} style={{ borderBottom: '1px solid #eee' }}>
                  <td style={{ padding: '12px' }}>{new Date(log.created_at).toLocaleString()}</td>
                  <td style={{ padding: '12px' }}>{log.username || 'System'}</td>
                  <td style={{ padding: '12px' }}>{log.event_type}</td>
                  <td style={{ padding: '12px' }}>
                    <span style={{
                      color: log.event_severity === 'WARNING' ? 'orange' : 
                             log.event_severity === 'ERROR' ? 'red' : 'green',
                      background: '#f0f0f0',
                      padding: '4px 8px',
                      borderRadius: '20px',
                      fontSize: '11px'
                    }}>
                      {log.event_severity}
                    </span>
                  </td>
                  <td style={{ padding: '12px' }}>{log.ip_address || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Layout>
  );
}

export default Admin;