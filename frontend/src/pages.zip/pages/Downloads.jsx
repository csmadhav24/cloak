import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';

function Downloads() {
  const [files, setFiles] = useState([]);
  const [downloading, setDownloading] = useState(null);

  useEffect(() => {
    fetchFiles();
  }, []);

  const fetchFiles = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8000/api/files/files', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setFiles(data.files || []);
    } catch (error) {
      console.error('Error fetching files:', error);
    }
  };

  const handleDownload = async (fileId, filename) => {
    setDownloading(fileId);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:8000/api/files/download/${fileId}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      // Get decryption metadata from headers
      const sha256Hash = response.headers.get('X-SHA256-Hash');
      const encryptedAesKey = response.headers.get('X-Encrypted-AES-Key');
      const iv = response.headers.get('X-IV');
      const authTag = response.headers.get('X-Auth-Tag');
      
      const encryptedBlob = await response.blob();
      
      // For now, save as encrypted file
      // (Full decryption would require user's RSA private key)
      const url = window.URL.createObjectURL(encryptedBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filename}.encrypted`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      
      alert(`Downloaded: ${filename}\nNote: File is encrypted. To decrypt, you need your RSA private key.`);
    } catch (error) {
      alert('Download failed: ' + error.message);
    } finally {
      setDownloading(null);
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <Layout title="Downloads">
      <div style={{ background: 'white', borderRadius: '10px', padding: '20px' }}>
        <h2>Available Files</h2>
        <p style={{ color: '#666', marginBottom: '20px' }}>
          Click download on any file. Files are encrypted and will be saved with .encrypted extension.
        </p>
        
        {files.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px', color: '#999' }}>
            No files available
          </div>
        ) : (
          <div style={{ display: 'grid', gap: '10px' }}>
            {files.map((file) => (
              <div
                key={file.id}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '15px',
                  border: '1px solid #eee',
                  borderRadius: '8px',
                  transition: 'box-shadow 0.3s'
                }}
              >
                <div>
                  <div style={{ fontWeight: 'bold' }}>📄 {file.original_filename}</div>
                  <div style={{ fontSize: '12px', color: '#666' }}>
                    {formatFileSize(file.file_size)} • Uploaded: {new Date(file.uploaded_at).toLocaleDateString()}
                  </div>
                </div>
                <button
                  onClick={() => handleDownload(file.id, file.original_filename)}
                  disabled={downloading === file.id}
                  style={{
                    background: '#667eea',
                    color: 'white',
                    border: 'none',
                    padding: '8px 16px',
                    borderRadius: '5px',
                    cursor: downloading === file.id ? 'not-allowed' : 'pointer',
                    opacity: downloading === file.id ? 0.7 : 1
                  }}
                >
                  {downloading === file.id ? 'Downloading...' : '📥 Download'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}

export default Downloads;